// Coordenadas del centro de Valencia
const VALENCIA_CENTER = [39.4699, -0.3763];
const VALENCIA_ZOOM = 13;

// Límites geográficos de la ciudad de Valencia
const VALENCIA_BOUNDS = [
    [39.42, -0.45],
    [39.52, -0.30]
];

// Inicializar mapa
const map = L.map('map', {
    center: VALENCIA_CENTER,
    zoom: VALENCIA_ZOOM,
    minZoom: 12,
    maxZoom: 18,
    maxBounds: VALENCIA_BOUNDS,
    maxBoundsViscosity: 1.0,
    zoomControl: false
});

// Usar tile layer estilo Google Maps
L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
    attribution: '© OpenStreetMap contributors © CARTO',
    subdomains: 'abcd',
    maxZoom: 20
}).addTo(map);

let userMarker = null;
let routeControl = null;
let parkingMarkers = [];
let searchMarker = null;
let currentParkingMarker = null; // Variable para el marcador PMR actual

// Icono personalizado estilo Google Maps para ubicación del usuario
const userLocationIcon = L.divIcon({
    className: 'custom-user-marker',
    html: `
        <div style="position: relative;">
            <div style="
                width: 20px;
                height: 20px;
                background: #4285F4;
                border: 4px solid white;
                border-radius: 50%;
                box-shadow: 0 2px 8px rgba(66, 133, 244, 0.6);
                position: absolute;
                top: -10px;
                left: -10px;
            "></div>
            <div style="
                width: 40px;
                height: 40px;
                background: rgba(66, 133, 244, 0.2);
                border-radius: 50%;
                position: absolute;
                top: -20px;
                left: -20px;
                animation: pulse-ring 2s infinite;
            "></div>
        </div>
    `,
    iconSize: [40, 40],
    iconAnchor: [20, 20]
});

const searchMarkerIcon = L.divIcon({
    className: 'custom-search-marker',
    html: `
        <div style="position: relative; width: 30px; height: 40px;">
            <div style="
                width: 30px;
                height: 30px;
                background: #EA4335;
                border: 3px solid white;
                border-radius: 50% 50% 50% 0;
                transform: rotate(-45deg);
                box-shadow: 0 4px 12px rgba(234, 67, 53, 0.5);
                position: absolute;
                top: 0;
                left: 0;
            ">
                <div style="
                    width: 12px;
                    height: 12px;
                    background: white;
                    border-radius: 50%;
                    position: absolute;
                    top: 50%;
                    left: 50%;
                    transform: translate(-50%, -50%) rotate(45deg);
                "></div>
            </div>
        </div>
    `,
    iconSize: [30, 40],
    iconAnchor: [15, 40],
    popupAnchor: [0, -40]
});

function locateMe() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const lat = position.coords.latitude;
                const lng = position.coords.longitude;
                
                if (userMarker) {
                    map.removeLayer(userMarker);
                }
                
                userMarker = L.marker([lat, lng], { icon: userLocationIcon }).addTo(map);
                
                L.circle([lat, lng], {
                    radius: position.coords.accuracy,
                    color: '#4285F4',
                    fillColor: '#4285F4',
                    fillOpacity: 0.15,
                    weight: 1
                }).addTo(map);
                
                map.setView([lat, lng], 15, { animate: true });
                
                userMarker.bindPopup(`
                    <div style="font-family: 'Segoe UI', sans-serif; text-align: center;">
                        <strong style="color: #4285F4;">📍 Tu ubicación</strong><br>
                        <small>Precisión: ${Math.round(position.coords.accuracy)}m</small>
                    </div>
                `).openPopup();
            },
            (error) => {
                alert('No se pudo obtener tu ubicación. Por favor, permite el acceso al GPS.');
            }
        );
    }
}

function searchLocation() {
    const query = document.getElementById('searchInput').value.trim();
    if (!query) {
        alert('Por favor, ingresa una ubicación para buscar');
        return;
    }
    
    fetch(`https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(query + ', Valencia')}&format=json&limit=1`)
        .then(response => response.json())
        .then(data => {
            if (data && data.length > 0) {
                const lat = parseFloat(data[0].lat);
                const lon = parseFloat(data[0].lon);
                
                // Eliminar marcador anterior de búsqueda si existe
                if (searchMarker) {
                    map.removeLayer(searchMarker);
                }
                
                // Eliminar marcador temporal PMR si existe
                if (currentParkingMarker) {
                    map.removeLayer(currentParkingMarker);
                    currentParkingMarker = null;
                }
                
                // Eliminar ruta anterior
                if (routeControl) {
                    map.removeControl(routeControl);
                    routeControl = null;
                }
                
                // Guardar datos para favoritos
                window._searchData = { name: data[0].display_name, lat: lat, lng: lon };

                searchMarker = L.marker([lat, lon], { icon: searchMarkerIcon }).addTo(map);
                searchMarker.bindPopup(createSearchPopupContent(data[0].display_name, lat, lon), {maxWidth: 400}).openPopup();
                
                map.setView([lat, lon], 16, { animate: true });

                // Comprobar si está en favoritos
                checkSearchFavorite(lat, lon);
            } else {
                alert('❌ No se encontró la ubicación. Intenta con otro término de búsqueda.');
            }
        })
        .catch(error => {
            console.error('Error en la búsqueda:', error);
            alert('❌ Error al realizar la búsqueda. Inténtalo de nuevo.');
        });
}

// Añadir listener para Enter en el input de búsqueda
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchLocation();
            }
        });
    }
});

function startNavigationTo(destLat, destLon) {
    if (!userMarker) {
        alert('Primero activa tu ubicación con el botón 📍');
        locateMe();
        return;
    }
    
    const userLatLng = userMarker.getLatLng();
    
    // Limpiar ruta anterior
    if (routeControl) {
        map.removeControl(routeControl);
    }
    
    // Mostrar botón cancelar ruta
    const cancelBtn = document.getElementById('cancelRouteBtn');
    if (cancelBtn) cancelBtn.style.display = 'block';
    
    // Limpiar marcador temporal anterior
    if (currentParkingMarker) {
        map.removeLayer(currentParkingMarker);
        currentParkingMarker = null;
    }
    
    // Crear marcador de destino si no existe el marcador de búsqueda
    if (!searchMarker) {
        const tempMarker = L.marker([destLat, destLon], { icon: searchMarkerIcon }).addTo(map);
        currentParkingMarker = tempMarker;
    }
    
    routeControl = L.Routing.control({
        waypoints: [
            L.latLng(userLatLng.lat, userLatLng.lng),
            L.latLng(destLat, destLon)
        ],
        routeWhileDragging: true,
        router: L.Routing.osrmv1({
            serviceUrl: 'https://router.project-osrm.org/route/v1'
        }),
        lineOptions: {
            styles: [{
                color: '#4285F4',
                opacity: 0.8,
                weight: 6
            }]
        },
        createMarker: function(i, waypoint, n) {
            if (i === 0) {
                return L.marker(waypoint.latLng, { icon: userLocationIcon });
            } else {
                return null; // No crear marcador, ya existe
            }
        },
        formatter: new L.Routing.Formatter({
            language: 'es'
        })
    }).addTo(map);
    
    // Escuchar cuando se calcula la ruta para mostrar instrucciones
    routeControl.on('routesfound', function(e) {
        const routes = e.routes;
        const summary = routes[0].summary;
        const instructions = routes[0].instructions;
        
        // Crear popup con información de la ruta
        let routeInfo = `
            <div style="font-family: 'Segoe UI', sans-serif; padding: 10px; min-width: 250px;">
                <div style="text-align: center; margin-bottom: 10px;">
                    <strong style="color: #4285F4; font-size: 16px;">🗺️ Ruta Calculada</strong>
                </div>
                <div style="background: #E3F2FD; padding: 10px; border-radius: 8px; margin-bottom: 8px;">
                    <div style="color: #1565C0; font-size: 13px; margin-bottom: 5px;">
                        📏 Distancia: <strong>${(summary.totalDistance / 1000).toFixed(2)} km</strong>
                    </div>
                    <div style="color: #1565C0; font-size: 13px;">
                        ⏱️ Tiempo estimado: <strong>${Math.round(summary.totalTime / 60)} min</strong>
                    </div>
                </div>`;
        
        // Agregar indicadores de tramos a pie si existen
        let walkingSegmentsFound = [];
        instructions.forEach((instruction, index) => {
            const text = instruction.text.toLowerCase();
            if (text.includes('caminar') || text.includes('andar') || text.includes('pie') || 
                text.includes('peatonal') || text.includes('paso de peatones') ||
                (instruction.distance < 100 && text.includes('girar'))) {
                walkingSegmentsFound.push({
                    index: index + 1,
                    text: instruction.text,
                    distance: instruction.distance
                });
            }
        });
        
        if (walkingSegmentsFound.length > 0) {
            routeInfo += `
                <div style="background: linear-gradient(135deg, #FFF3E0 0%, #FFE0B2 100%); padding: 10px; border-radius: 8px; border-left: 4px solid #FF9800; margin-top: 8px;">
                    <div style="color: #E65100; font-size: 13px; font-weight: 600; margin-bottom: 6px; display: flex; align-items: center; gap: 5px;">
                        🚶 Tramos a pie detectados:
                    </div>`;
            
            walkingSegmentsFound.forEach(segment => {
                routeInfo += `
                    <div style="background: white; padding: 6px; border-radius: 5px; margin-top: 5px; font-size: 11px; color: #555;">
                        <strong>Paso ${segment.index}:</strong> ${segment.text}
                        ${segment.distance > 0 ? `<br><small style="color: #888;">📏 ${segment.distance}m</small>` : ''}
                    </div>`;
            });
            
            routeInfo += `</div>`;
        }
        
        routeInfo += `
                <div style="background: linear-gradient(135deg, #4285F4 0%, #1976D2 100%); padding: 10px; border-radius: 8px; text-align: center; margin-top: 10px; color: white;">
                    <small style="font-size: 12px;">💡 Sigue las indicaciones en el mapa</small>
                </div>
            </div>`;
        
        // Mostrar popup
        if (searchMarker) {
            searchMarker.bindPopup(routeInfo).openPopup();
        } else if (currentParkingMarker) {
            currentParkingMarker.bindPopup(routeInfo).openPopup();
        }
    });
    
    // Cerrar popups existentes
    map.closePopup();
}

function showRoutePanel() {
    document.getElementById('routePanel').classList.add('show');
}

function closeRoutePanel() {
    document.getElementById('routePanel').classList.remove('show');
}

// ===== FAVORITOS =====
window._userFavorites = [];
window._searchData = null;

function loadUserFavorites() {
    const userId = localStorage.getItem('userId');
    if (!userId) return;
    fetch('auth/get_favorites.php?user_id=' + encodeURIComponent(userId))
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                window._userFavorites = data.favorites;
                updateFavoritesDropdown();
            }
        })
        .catch(() => {});
}

function updateFavoritesDropdown() {
    const select = document.getElementById('favoritesSelect');
    const section = document.getElementById('favoritesDropdownSection');
    if (!select || !section) return;

    const userId = localStorage.getItem('userId');
    if (!userId) {
        section.style.display = 'none';
        return;
    }

    section.style.display = 'block';
    select.innerHTML = '';

    if (window._userFavorites.length === 0) {
        select.innerHTML = '<option value="">Sin favoritos guardados</option>';
        return;
    }

    select.innerHTML = '<option value="">-- Selecciona un favorito --</option>';
    window._userFavorites.forEach(function(fav, idx) {
        const opt = document.createElement('option');
        opt.value = idx;
        const shortName = fav.nombre.length > 60 ? fav.nombre.substring(0, 57) + '...' : fav.nombre;
        opt.textContent = shortName;
        select.appendChild(opt);
    });
}

function goToSelectedFavorite() {
    const select = document.getElementById('favoritesSelect');
    if (!select || select.value === '') {
        alert('Selecciona una ubicación favorita');
        return;
    }
    const fav = window._userFavorites[parseInt(select.value)];
    if (!fav) return;
    navigateToTarget({ lat: fav.lat, lng: fav.lng, name: fav.nombre });
}

function createSearchPopupContent(name, lat, lng) {
    const escapedName = name
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');

    return `
        <div style="font-family: 'Segoe UI', sans-serif; min-width: 260px; max-width: 300px; padding: 0;">
            <div style="background: linear-gradient(135deg, #f8fafc, #eef2ff); padding: 12px 14px; border-radius: 8px; margin-bottom: 10px; border-left: 3px solid #667eea;">
                <div style="font-size: 11px; color: #667eea; font-weight: 600; margin-bottom: 4px; text-transform: uppercase; letter-spacing: 0.5px;">Ubicación</div>
                <div style="color: #1e293b; font-size: 13px; font-weight: 500; line-height: 1.4;">
                    ${escapedName}
                </div>
            </div>
            <div style="display: flex; gap: 6px;">
                <button onclick="startNavigationTo(${lat}, ${lng})" style="
                    flex: 1;
                    padding: 9px 10px;
                    background: linear-gradient(135deg, #2980b9 0%, #3498db 100%);
                    color: white;
                    border: none;
                    border-radius: 10px;
                    cursor: pointer;
                    font-size: 12px;
                    font-weight: 600;
                    box-shadow: 0 3px 10px rgba(52, 152, 219, 0.35);
                    transition: all 0.3s ease;
                " onmouseover="this.style.transform='translateY(-1px)'; this.style.boxShadow='0 5px 14px rgba(52,152,219,0.5)'" onmouseout="this.style.transform=''; this.style.boxShadow='0 3px 10px rgba(52,152,219,0.35)'">
                    Cómo llegar
                </button>
                <button id="favStarBtn" data-fav="false" onclick="toggleSearchFavorite()" style="
                    flex: 1;
                    padding: 9px 10px;
                    background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
                    color: white;
                    border: none;
                    border-radius: 10px;
                    cursor: pointer;
                    font-size: 12px;
                    font-weight: 600;
                    box-shadow: 0 3px 10px rgba(245, 158, 11, 0.35);
                    transition: all 0.3s ease;
                " onmouseover="this.style.transform='translateY(-1px)'; this.style.boxShadow='0 5px 14px rgba(245,158,11,0.5)'" onmouseout="this.style.transform=''; this.style.boxShadow='0 3px 10px rgba(245,158,11,0.35)'">
                    <span id="favStarIcon">☆</span> Favorito
                </button>
            </div>
        </div>
    `;
}

function checkSearchFavorite(lat, lng) {
    setTimeout(() => {
        const starBtn = document.getElementById('favStarBtn');
        if (!starBtn) return;
        const isFav = window._userFavorites.some(f =>
            Math.abs(f.lat - lat) < 0.0001 && Math.abs(f.lng - lng) < 0.0001
        );
        const iconEl = document.getElementById('favStarIcon');
        if (isFav) {
            starBtn.dataset.fav = 'true';
            starBtn.style.background = 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)';
            starBtn.style.boxShadow = '0 4px 12px rgba(239, 68, 68, 0.4)';
            if (iconEl) iconEl.textContent = '\u2605';
            starBtn.innerHTML = '<span id="favStarIcon">\u2605</span> Quitar de favoritos';
        } else {
            starBtn.dataset.fav = 'false';
            starBtn.style.background = 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)';
            starBtn.style.boxShadow = '0 4px 12px rgba(245, 158, 11, 0.4)';
            starBtn.innerHTML = '<span id="favStarIcon">\u2606</span> Guardar en favoritos';
        }
    }, 50);
}

function toggleSearchFavorite() {
    const userId = localStorage.getItem('userId');
    if (!userId) {
        alert('Debes iniciar sesión para guardar favoritos');
        return;
    }
    const starBtn = document.getElementById('favStarBtn');
    if (!starBtn || !window._searchData) return;

    const name = window._searchData.name;
    const lat = window._searchData.lat;
    const lng = window._searchData.lng;

    if (starBtn.dataset.fav === 'true') {
        fetch('auth/delete_favorite.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ user_id: parseInt(userId), lat: lat, lng: lng })
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                starBtn.dataset.fav = 'false';
                starBtn.style.background = 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)';
                starBtn.style.boxShadow = '0 4px 12px rgba(245, 158, 11, 0.4)';
                starBtn.innerHTML = '<span id="favStarIcon">\u2606</span> Guardar en favoritos';
                window._userFavorites = window._userFavorites.filter(f =>
                    !(Math.abs(f.lat - lat) < 0.0001 && Math.abs(f.lng - lng) < 0.0001)
                );
                updateFavoritesDropdown();
            }
        });
    } else {
        fetch('auth/save_favorite.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ user_id: parseInt(userId), nombre: name, lat: lat, lng: lng })
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                starBtn.dataset.fav = 'true';
                starBtn.style.background = 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)';
                starBtn.style.boxShadow = '0 4px 12px rgba(239, 68, 68, 0.4)';
                starBtn.innerHTML = '<span id="favStarIcon">\u2605</span> Quitar de favoritos';
                window._userFavorites.push({ id: data.id, nombre: name, lat: lat, lng: lng });
                updateFavoritesDropdown();
            }
        });
    }
}

function navigateToTarget(target) {
    if (searchMarker) map.removeLayer(searchMarker);
    if (currentParkingMarker) { map.removeLayer(currentParkingMarker); currentParkingMarker = null; }
    if (routeControl) { map.removeControl(routeControl); routeControl = null; }

    window._searchData = { name: target.name, lat: target.lat, lng: target.lng };

    searchMarker = L.marker([target.lat, target.lng], { icon: searchMarkerIcon }).addTo(map);
    searchMarker.bindPopup(createSearchPopupContent(target.name, target.lat, target.lng), {maxWidth: 400}).openPopup();
    map.setView([target.lat, target.lng], 16, { animate: true });
    checkSearchFavorite(target.lat, target.lng);
}

function calculateRoute() {
    const origin = document.getElementById('origin').value;
    const destination = document.getElementById('destination').value;
    
    if (!origin || !destination) {
        alert('Por favor, ingresa origen y destino');
        return;
    }
    
    // Limpiar marcadores anteriores
    if (searchMarker) {
        map.removeLayer(searchMarker);
        searchMarker = null;
    }
    
    if (currentParkingMarker) {
        map.removeLayer(currentParkingMarker);
        currentParkingMarker = null;
    }
    
    if (routeControl) {
        map.removeControl(routeControl);
    }
    
    // Mostrar botón cancelar ruta
    const cancelBtn = document.getElementById('cancelRouteBtn');
    if (cancelBtn) cancelBtn.style.display = 'block';

    Promise.all([
        fetch(`https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(origin + ', Valencia')}&format=json&limit=1`),
        fetch(`https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(destination + ', Valencia')}&format=json&limit=1`)
    ])
    .then(responses => Promise.all(responses.map(r => r.json())))
    .then(([originData, destData]) => {
        if (originData.length > 0 && destData.length > 0) {
            routeControl = L.Routing.control({
                waypoints: [
                    L.latLng(parseFloat(originData[0].lat), parseFloat(originData[0].lon)),
                    L.latLng(parseFloat(destData[0].lat), parseFloat(destData[0].lon))
                ],
                routeWhileDragging: true,
                lineOptions: {
                    styles: [{
                        color: '#4285F4',
                        opacity: 0.8,
                        weight: 6
                    }]
                },
                createMarker: function(i, waypoint, n) {
                    return L.marker(waypoint.latLng, {
                        icon: searchMarkerIcon
                    });
                },
                formatter: new L.Routing.Formatter({
                    language: 'es'
                })
            }).addTo(map);
            
            // Agregar el mismo listener para mostrar información de tramos a pie
            routeControl.on('routesfound', function(e) {
                const routes = e.routes;
                const instructions = routes[0].instructions;
                
                let walkingSegments = [];
                instructions.forEach((instruction, index) => {
                    const text = instruction.text.toLowerCase();
                    if (text.includes('caminar') || text.includes('andar') || text.includes('pie') || 
                        text.includes('peatonal') || text.includes('paso de peatones') ||
                        (instruction.distance < 100 && text.includes('girar'))) {
                        walkingSegments.push(instruction.text);
                    }
                });
                
                if (walkingSegments.length > 0) {
                    console.log('⚠️ Ruta con tramos a pie detectados:', walkingSegments);
                }
            });
        } else {
            alert('No se pudieron encontrar las ubicaciones');
        }
    });
}






