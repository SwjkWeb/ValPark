// ===== CONFIGURACIÓN DE LA APP =====
// Cambia API_BASE_URL a la URL de tu servidor en producción.
// En desarrollo local (XAMPP), déjalo vacío ''.
// En producción (APK), pon la URL completa de tu backend, ej:
//   const API_BASE_URL = 'https://tu-servidor.com/';

const API_BASE_URL = ''; // Desarrollo local
// const API_BASE_URL = 'https://tu-servidor.com/'; // Producción
