<?php
require_once 'config.php';

$user_id = isset($_GET['user_id']) ? (int)$_GET['user_id'] : 0;

if ($user_id <= 0) {
    echo json_encode(['success' => false, 'favorites' => []]);
    exit;
}

$conn = getDBConnection();
if (!$conn) {
    echo json_encode(['success' => false, 'favorites' => []]);
    exit;
}

$conn->query("CREATE TABLE IF NOT EXISTS rutas_favoritas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    nombre VARCHAR(500) NOT NULL,
    lat DECIMAL(10,8) NOT NULL,
    lng DECIMAL(11,8) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$stmt = $conn->prepare("SELECT id, nombre, lat, lng, created_at FROM rutas_favoritas WHERE user_id = ? ORDER BY created_at DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$favorites = [];
while ($row = $result->fetch_assoc()) {
    $favorites[] = [
        'id' => (int)$row['id'],
        'nombre' => $row['nombre'],
        'lat' => (float)$row['lat'],
        'lng' => (float)$row['lng'],
        'created_at' => $row['created_at']
    ];
}

echo json_encode(['success' => true, 'favorites' => $favorites]);
$stmt->close();
$conn->close();
?>
