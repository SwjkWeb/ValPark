<?php
require_once 'config.php';

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Datos incompletos']);
    exit;
}

$user_id = (int)$input['user_id'];

if ($user_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Usuario no válido']);
    exit;
}

$conn = getDBConnection();
if (!$conn) {
    echo json_encode(['success' => false, 'message' => 'Error de conexión']);
    exit;
}

if (isset($input['id'])) {
    // Eliminar por ID
    $id = (int)$input['id'];
    $stmt = $conn->prepare("DELETE FROM rutas_favoritas WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $id, $user_id);
} elseif (isset($input['lat']) && isset($input['lng'])) {
    // Eliminar por coordenadas
    $lat = (float)$input['lat'];
    $lng = (float)$input['lng'];
    $stmt = $conn->prepare("DELETE FROM rutas_favoritas WHERE user_id = ? AND ABS(lat - ?) < 0.0001 AND ABS(lng - ?) < 0.0001");
    $stmt->bind_param("idd", $user_id, $lat, $lng);
} else {
    echo json_encode(['success' => false, 'message' => 'Datos incompletos']);
    $conn->close();
    exit;
}

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Error al eliminar']);
}

$stmt->close();
$conn->close();
?>
