<?php
require_once 'config.php';

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['user_id']) || !isset($input['current_password']) || !isset($input['new_password'])) {
    echo json_encode(['success' => false, 'message' => 'Datos incompletos']);
    exit;
}

$user_id = (int)$input['user_id'];
$current_password = $input['current_password'];
$new_password = $input['new_password'];

if ($user_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Usuario no válido']);
    exit;
}

if (strlen($new_password) < 6) {
    echo json_encode(['success' => false, 'message' => 'La nueva contraseña debe tener al menos 6 caracteres']);
    exit;
}

$conn = getDBConnection();
if (!$conn) {
    echo json_encode(['success' => false, 'message' => 'Error de conexión']);
    exit;
}

$stmt = $conn->prepare("SELECT password FROM usuarios WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'Usuario no encontrado']);
    $stmt->close();
    $conn->close();
    exit;
}

$user = $result->fetch_assoc();
$stmt->close();

if (!password_verify($current_password, $user['password'])) {
    echo json_encode(['success' => false, 'message' => 'La contraseña actual es incorrecta']);
    $conn->close();
    exit;
}

$hashed = password_hash($new_password, PASSWORD_DEFAULT);
$updateStmt = $conn->prepare("UPDATE usuarios SET password = ? WHERE id = ?");
$updateStmt->bind_param("si", $hashed, $user_id);

if ($updateStmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Contraseña actualizada correctamente']);
} else {
    echo json_encode(['success' => false, 'message' => 'Error al actualizar la contraseña']);
}

$updateStmt->close();
$conn->close();
?>
