<?php
require_once 'config.php';

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['user_id']) || !isset($input['nombre']) || !isset($input['lat']) || !isset($input['lng'])) {
    echo json_encode(['success' => false, 'message' => 'Datos incompletos']);
    exit;
}

$user_id = (int)$input['user_id'];
$nombre = trim($input['nombre']);
$lat = (float)$input['lat'];
$lng = (float)$input['lng'];

if ($user_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Usuario no válido']);
    exit;
}

if ($lat < -90 || $lat > 90 || $lng < -180 || $lng > 180) {
    echo json_encode(['success' => false, 'message' => 'Coordenadas inválidas']);
    exit;
}

$conn = getDBConnection();
if (!$conn) {
    echo json_encode(['success' => false, 'message' => 'Error de conexión']);
    exit;
}

$conn->query("CREATE TABLE IF NOT EXISTS rutas_favoritas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    nombre VARCHAR(500) NOT NULL,
    lat DECIMAL(10,8) NOT NULL,
    lng DECIMAL(11,8) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// Verificar si ya existe
$checkStmt = $conn->prepare("SELECT id FROM rutas_favoritas WHERE user_id = ? AND ABS(lat - ?) < 0.0001 AND ABS(lng - ?) < 0.0001");
$checkStmt->bind_param("idd", $user_id, $lat, $lng);
$checkStmt->execute();
$checkResult = $checkStmt->get_result();

if ($checkResult->num_rows > 0) {
    echo json_encode(['success' => false, 'message' => 'Ya existe en favoritos']);
    $checkStmt->close();
    $conn->close();
    exit;
}
$checkStmt->close();

$stmt = $conn->prepare("INSERT INTO rutas_favoritas (user_id, nombre, lat, lng) VALUES (?, ?, ?, ?)");
$stmt->bind_param("isdd", $user_id, $nombre, $lat, $lng);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'id' => $conn->insert_id]);
} else {
    echo json_encode(['success' => false, 'message' => 'Error al guardar']);
}

$stmt->close();
$conn->close();
?>
