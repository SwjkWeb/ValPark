<?php
require_once 'config.php';

$conn = getDBConnection();
if (!$conn) {
    echo json_encode(['success' => false, 'markers' => []]);
    exit;
}

$conn->query("CREATE TABLE IF NOT EXISTS marcadores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    lat DECIMAL(10,8) NOT NULL,
    lng DECIMAL(11,8) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    expires_at DATETIME NOT NULL,
    INDEX idx_expires (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// Eliminar marcadores expirados
$conn->query("DELETE FROM marcadores WHERE expires_at < NOW()");

$result = $conn->query("SELECT id, lat, lng, TIMESTAMPDIFF(SECOND, NOW(), expires_at) AS secs_left FROM marcadores WHERE expires_at > NOW()");

$markers = [];
while ($row = $result->fetch_assoc()) {
    $markers[] = [
        'id'       => (int)$row['id'],
        'lat'      => (float)$row['lat'],
        'lng'      => (float)$row['lng'],
        'ms_left'  => (int)$row['secs_left'] * 1000
    ];
}

echo json_encode(['success' => true, 'markers' => $markers]);
$conn->close();
?>