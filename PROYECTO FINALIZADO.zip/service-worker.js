const CACHE_NAME = 'valpark-v1';
const ASSETS = [
  '/',
  '/index.html',
  '/gps.html',
  '/styles.css',
  '/script.js',
  '/js/config.js',
  '/IMG/logo.png',
  '/manifest.json'
];

// Instalar: cachear recursos estáticos
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(ASSETS))
      .then(() => self.skipWaiting())
  );
});

// Activar: limpiar caches antiguos
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

// Fetch: network first, fallback a cache
self.addEventListener('fetch', event => {
  // No cachear peticiones al backend PHP
  if (event.request.url.includes('/auth/')) {
    return;
  }
  event.respondWith(
    fetch(event.request)
      .then(response => {
        const clone = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
        return response;
      })
      .catch(() => caches.match(event.request))
  );
});
